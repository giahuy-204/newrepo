<html>
    <body>
        cảm ơn bạn: <?= $_POST["name"] ?> đã donate số  tiền <?= $_POST["money"] ?>
    </body>
</html>
