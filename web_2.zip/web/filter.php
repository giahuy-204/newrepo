<?php
    require_once('mysql.php');
    if (isset($_POST['submit'])) {
        $F_date = $POST['date'];
        if () {
            
        }
    }
?>